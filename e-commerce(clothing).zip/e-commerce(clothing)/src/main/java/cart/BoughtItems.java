package cart;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class BoughtItems {
	private int boughtItemsId;
    private String username;
    private List<BoughtProduct> boughtProducts;
    private double total;
    private Date boughtDate;

    public BoughtItems() {
        boughtProducts = new ArrayList<BoughtProduct>();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public List<BoughtProduct> getBoughtProducts() {
        return boughtProducts;
    }

    public void setBoughtProducts(List<BoughtProduct> boughtProducts) {
        this.boughtProducts = boughtProducts;
    }

    public void addBoughtProduct(BoughtProduct boughtProduct) {
    	if (boughtProducts == null) {
            boughtProducts = new ArrayList<>();
        }
        boughtProducts.add(boughtProduct);
        total += Double.parseDouble(boughtProduct.getProductPrice().replace("$", "")) * boughtProduct.getQuantity();
    }


    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Date getBoughtDate() {
        return boughtDate;
    }

    public void setBoughtDate(Date boughtDate) {
        this.boughtDate = boughtDate;
    }
    public double getboughtItemsId() {
        return boughtItemsId;
    }
	public void setboughtItemsId(int boughtItemsId) {
		 this.boughtItemsId= boughtItemsId;
		
	}
}
