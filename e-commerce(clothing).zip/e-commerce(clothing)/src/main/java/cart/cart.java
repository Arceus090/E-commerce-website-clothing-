package cart;

import java.util.ArrayList;
import java.util.List;

import model.Products;

public class cart {
    private List<CartItem> items;

    public cart() {
        items = new ArrayList<>();
    }

    public List<CartItem> getItems() {
        return items;
    }

    public void addItem(Products product, int quantity) {
        for (CartItem item : items) {
            if (item.getProduct().getProductId() == product.getProductId()) {
                item.setQuantity(item.getQuantity() + quantity);
                return;
            }
        }
        items.add(new CartItem(product, quantity));
    }

    public void removeItem(int productId) {
        for (CartItem item : items) {
            if (item.getProduct().getProductId() == productId) {
                items.remove(item);
                return;
            }
        }
    }

    public void clear() {
        items.clear();
    }

    public double getTotal() {
        double total = 0;
        for (CartItem item : items) {
            double price = Double.parseDouble(item.getProduct().getProductPrice().replace("$", ""));
            total += price * item.getQuantity();
        }
        // Remove dollar sign from string before parsing as number
        String totalStr = String.valueOf(total).replace("$", "");
        return Double.parseDouble(totalStr);
    }
}