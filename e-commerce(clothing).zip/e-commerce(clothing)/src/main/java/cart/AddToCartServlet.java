package cart;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import extraction.everyproduct;
import model.Products;

@WebServlet("/cart")
public class AddToCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        cart cart = (cart) session.getAttribute("cart");
        everyproduct productDao = new everyproduct();
        
        if (cart == null) {
            cart = new cart();
        }

        if (action != null && action.equals("remove")) {
            int productId = Integer.parseInt(request.getParameter("productId"));
            cart.removeItem(productId);
        } else if (action != null && action.equals("clear")) {
            cart.clear();
        } else if (action != null && action.equals("buy")) {
            String username = (String) session.getAttribute("username");
            if (username == null) {
                response.sendRedirect("Login.jsp");
                return;
            }
            List<CartItem> items = cart.getItems();
            BoughtItems boughtItems = new BoughtItems();
            boughtItems.setUsername(username);
            boughtItems.setBoughtDate(new Date(0));
            for (CartItem item : items) {
                Products product = item.getProduct();
                BoughtProduct boughtProduct = new BoughtProduct();
                boughtProduct.setProductName(product.getProductName());
                boughtProduct.setProductImage(product.getProductImage());
                boughtProduct.setProductPrice(product.getProductPrice());
                boughtProduct.setQuantity(item.getQuantity());
                boughtItems.addBoughtProduct(boughtProduct);
                // Add the bought product to the cart database
                CartDao cartDao = new CartDao();
                cartDao.addBoughtProduct(username, boughtItems.getBoughtDate(), boughtProduct);
                System.out.println("Added bought product to database: " + boughtProduct.toString());
            }
            cart.clear();
            session.setAttribute("boughtItems", boughtItems);
            session.setAttribute("boughtItemsId", boughtItems);
            response.sendRedirect(request.getContextPath() + "/bought.jsp");
            return;
        
        } else {
            int productId = Integer.parseInt(request.getParameter("productId"));
            Products product = productDao.getProductById(productId);
            cart.addItem(product, 1);
        }

        List<CartItem> items = cart.getItems();
        session.setAttribute("cart", cart);
        session.setAttribute("cartSize", items.size());
        session.setAttribute("cartTotal", cart.getTotal());
        response.sendRedirect(request.getContextPath() + "/cart.jsp");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}