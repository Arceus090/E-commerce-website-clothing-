package cart;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CartDao {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/beast";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public void addBoughtProduct(String username, Date boughtDate, BoughtProduct boughtProduct) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "INSERT INTO bought_items (username, bought_date) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            stmt.setString(1, username);
            stmt.setTimestamp(2, new java.sql.Timestamp(boughtDate.getTime()));
            stmt.executeUpdate();
            int boughtItemsId;
            try (var rs = stmt.getGeneratedKeys()) {
                rs.next();
                boughtItemsId = rs.getInt(1);
            }
            sql = "INSERT INTO bought_products (bought_items_id, product_name, product_image, product_price, quantity) VALUES (?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, boughtItemsId);
            stmt.setString(2, boughtProduct.getProductName());
            stmt.setString(3, boughtProduct.getProductImage());
            stmt.setBigDecimal(4, new BigDecimal(boughtProduct.getProductPrice().substring(1)));
            stmt.setInt(5, boughtProduct.getQuantity());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    

    }
    

    public List<BoughtItems> getBoughtItems(String username) {
        List<BoughtItems> boughtItemsList = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT * FROM bought_items WHERE username = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                BoughtItems boughtItems = new BoughtItems();
                boughtItems.setboughtItemsId(rs.getInt("bought_items_id"));
                boughtItems.setUsername(rs.getString("username"));
                boughtItems.setBoughtDate(rs.getDate("bought_date"));
                boughtItemsList.add(boughtItems);
            }
            for (BoughtItems boughtItems : boughtItemsList) {
                sql = "SELECT * FROM bought_products WHERE bought_items_id = ?";
                stmt = conn.prepareStatement(sql);
                stmt.setInt(1, (int) boughtItems.getboughtItemsId());
                rs = stmt.executeQuery();
                while (rs.next()) {
                    BoughtProduct boughtProduct = new BoughtProduct();
                    boughtProduct.setProductName(rs.getString("product_name"));
                    boughtProduct.setProductImage(rs.getString("product_image"));
                    boughtProduct.setProductPrice(rs.getString("product_price"));
                    boughtProduct.setQuantity(rs.getInt("quantity"));
                    boughtItems.addBoughtProduct(boughtProduct);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return boughtItemsList;
    }

}