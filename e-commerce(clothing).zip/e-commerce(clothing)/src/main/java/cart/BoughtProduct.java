package cart;

public class BoughtProduct {
    private int id;
    private String productName;
    private String productImage;
    private String productPrice;
    private String username;
    private int quantity;

    public int getBoughtItemsId() {
        return id;
    }

    public void setBoughtItemsId(int id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public String getUsername() {
        return username;
    }

	public void setUsername(String username) {
		 this.username = username;
		
	}
}
