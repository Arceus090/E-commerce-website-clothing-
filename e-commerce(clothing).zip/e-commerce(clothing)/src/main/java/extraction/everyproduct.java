package extraction;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.Products;

public class everyproduct {
    public List<Products> getAllProducts() {
        List<Products> products = new ArrayList<>();
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Connect to the database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/beast", "root", "");

            // Create a SQL statement
            Statement stmt = conn.createStatement();

            // Execute the statement and retrieve the results
            ResultSet rs = stmt.executeQuery("SELECT * FROM product");

            // Loop through the results and create product objects
            while (rs.next()) {
                int productId = rs.getInt("product_id");
                String productName = rs.getString("product_name");
                String productImage = rs.getString("product_price");
                String productCategory = rs.getString("product_description");
                String productPrice = rs.getString("product_image");
                String productDescription = rs.getString("product_category");

                Products product = new Products(productId, productName, productPrice, productDescription, productImage, productCategory);
                products.add(product);
            }

            // Close the connection and statement
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return products;
    }
    
    public Products getProductById(int productId) {
        Products product = null;
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Connect to the database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/beast", "root", "");

            // Create a SQL statement
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM product WHERE product_id = ?");

            // Set the parameter values
            stmt.setInt(1, productId);

            // Execute the statement and retrieve the results
            ResultSet rs = stmt.executeQuery();

            // If a row was returned, create the product object
            if (rs.next()) {
            	
                String productName = rs.getString("product_name");
                String productImage = rs.getString("product_price");
                String productCategory = rs.getString("product_description");
                String productPrice = rs.getString("product_image");
                String productDescription = rs.getString("product_category");

                product = new Products(productId, productName, productPrice, productDescription, productImage, productCategory);
            }

            // Close the connection, statement, and result sets
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return product;
    }
    
    
    public void deleteProduct(int productId) {
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Connect to the database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/beast", "root", "");

            // Create a SQL statement
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM product WHERE product_id = ?");

            // Set the parameter values
            stmt.setInt(1, productId);

            // Execute the statement
            stmt.executeUpdate();

            // Close the connection and statement
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateProduct(int productId, String productName, String productPrice, String productDescription, String productImage, String productCategory) {
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Connect to the database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/beast", "root", "");

            // Create a SQL statement
            PreparedStatement stmt = conn.prepareStatement("UPDATE product SET product_name = ?, product_price = ?, product_description = ?, product_image = ?, product_category = ? WHERE product_id = ?");

            // Set the parameter values
            stmt.setString(1, productName);
            stmt.setString(2, productPrice);
            stmt.setString(3, productDescription);
            stmt.setString(4, productImage);
            stmt.setString(5, productCategory);
            stmt.setInt(6, productId);

            // Execute the statement
            stmt.executeUpdate();

            // Close the connection and statement
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    
    }


