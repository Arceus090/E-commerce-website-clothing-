package admin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Products;


@WebServlet("/admin")
public class AdminServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private Connection conn;

    public void init() throws ServletException {
        // Load JDBC driver and connect to the database
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/beast";
            String user = "root";
            String password = "";
            conn = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException | SQLException e) {
        	throw new ServletException("Error initializing database connection", e);
        }
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/allproducts.jsp");
        dispatcher.forward(request, response);

     
  
       
    }

private Products getProductById(int id) {
        Products product = null;
        if (conn != null) {
            try {
                String sql = "SELECT * FROM product WHERE product_id=?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, id);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    product = new Products(id, sql, sql, sql, sql, sql);
                    product.setProductId(rs.getInt("product_id"));
                    product.setProductName(rs.getString("product_name"));
                    product.setProductPrice(rs.getString("product_price"));
                    product.setProductDescription(rs.getString("product_description"));
                    product.setProductImage(rs.getString("product_image"));
                    product.setProductCategory(rs.getString("product_category"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return product;
    }

   
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get action parameter from the form
    	
        String action = request.getParameter("action");

        // Perform the appropriate action based on the parameter
        if (action != null) {
        switch (action) {
            case "add":
                addProduct(request, response);
                break;
            case "update":
                updateProduct(request, response);
                
                break;
            case "delete":
                deleteProduct(request, response);
                
                break;
            default:
                response.sendRedirect(request.getContextPath() + "/admin");
                break;
        }
        }else {
            response.sendRedirect(request.getContextPath() + "/admin");
        }
    }

   
	private void addProduct(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
		 
		 PrintWriter printOut = response.getWriter();
        // Get product data from the form
        String name = request.getParameter("name");
        String price = request.getParameter("price");
        String description = request.getParameter("description");
        String image = request.getParameter("image");
        String category = request.getParameter("category");

        // Check for null or empty values
        if (name == null || name.isEmpty() || price == null || price.isEmpty() || description == null || description.isEmpty() || image == null || image.isEmpty() || category == null || category.isEmpty()) {
            throw new ServletException("Invalid product data");
        }

        // Insert product data into the database
        if (conn != null) {
            try {
                String sql = "INSERT INTO product (product_name, product_price, product_description, product_image, product_category) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, name);
                stmt.setString(2, price);
                stmt.setString(3, description);
                stmt.setString(4, image);
                stmt.setString(5, category);
                int rowsInserted = stmt.executeUpdate();
               
                if (rowsInserted > 0) {
                	
                    System.out.println("A new product was inserted successfully!");
                    printOut.println("<script>alert('A new product was inserted successfully!');"
                            + "window.location.href='allproducts.jsp';</script>");
                   
                } else {
                    System.out.println("Failed to insert a new product!");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

       
    }

	
	 
	 
	
	private void updateProduct(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
		 PrintWriter printOut = response.getWriter();
		   String action = request.getParameter("action");

	        if (action != null && action.equals("update")) {
	            int id = Integer.parseInt(request.getParameter("id"));
	            Products product = getProductById(id);
	            request.setAttribute("product", product);
	            RequestDispatcher dispatcher1 = request.getRequestDispatcher("/editproduct.jsp");
	            dispatcher1.forward(request, response);
	        } else {
	            RequestDispatcher dispatcher1 = request.getRequestDispatcher("/allproducts.jsp");
	            dispatcher1.forward(request, response);
	        }
	        // Get product data from the form
	        int id = Integer.parseInt(request.getParameter("id"));
	        String name = request.getParameter("name");
	        String price = request.getParameter("price");
	        String description = request.getParameter("description");
	        String image = request.getParameter("image");
	        String category = request.getParameter("category");

	        // Check for null or empty values
	        if (name == null || name.isEmpty() || price == null || price.isEmpty() || description == null || description.isEmpty() || image == null || image.isEmpty() || category == null || category.isEmpty()) {
	            throw new ServletException("Invalid product data");
	        }

	        // Update product data in the database
	        if (conn != null) {
	            try {
	                String sql = "UPDATE product SET product_name=?, product_price=?, product_description=?, product_image=?, product_category=? WHERE product_id=?";
	                PreparedStatement stmt = conn.prepareStatement(sql);
	                stmt.setString(1, name);
	                stmt.setString(2, price);
	                stmt.setString(3, description);
	                stmt.setString(4, image);
	                stmt.setString(5, category);
	                stmt.setInt(6, id);
	                int rowsUpdated = stmt.executeUpdate();
	                if (rowsUpdated > 0) {
	                    System.out.println("Product updated successfully!");
	                    printOut.println("<script>alert('Product updated successfully!');"
	                            + "window.location.href='allproducts.jsp';</script>");
	                } else {
	                    System.out.println("Failed to update product!");
	                }
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }

	    }

	 private void deleteProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		    // Get the product ID from the request parameter
		    int productId = Integer.parseInt(request.getParameter("id"));
		    PrintWriter printOut = response.getWriter();
		    // Delete the product from the database
		    if (conn != null) {
		        try {
		            String sql = "DELETE FROM product WHERE product_id=?";
		            PreparedStatement stmt = conn.prepareStatement(sql);
		            stmt.setInt(1, productId);
		            stmt.executeUpdate();
		            printOut.println("<script>alert('Product deleted successfully!');"
                            + "window.location.href='allproducts.jsp';</script>");
		        } catch (SQLException e) {
		            throw new ServletException("Error deleting product from database", e);
		        }
		    }

		}

    public void destroy() {
        // Close the database connection
        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
