package profile;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import resources.MyCipher;

@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private Connection conn;

    public void init() {
        // Load JDBC driver and connect to the database
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/beast";
            String user = "root";
            String password = "";
            conn = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get username,email,image from session
    	HttpSession session = request.getSession();
    	String email = (String) session.getAttribute("username");
    	String fullName = (String) session.getAttribute("fullName");
    	String image = (String) session.getAttribute("imageName");
    
        // Get user data from the database
        try {
        	String sql = "SELECT * FROM register WHERE Email = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
               
                request.setAttribute("fullName", fullName);
                request.setAttribute("email", email);
                request.setAttribute("imageName", image);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Forward to the Profile JSP
        request.getRequestDispatcher("/MyAccount.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get username from session
    	HttpSession session = request.getSession();
    	String email = (String) session.getAttribute("username");
    	
    

        // Get user data from the form
        String newFullName = request.getParameter("fullName");
        String newEmail = request.getParameter("email");
        String newPassword = request.getParameter("password");

        // Encrypt the new password
        String encryptedNewPassword = null;
        try {
            encryptedNewPassword = MyCipher.encrypt(newPassword, "monkeydluffyyyyy");
        } catch (Exception e1) {
            e1.printStackTrace();
        }

        // Update user data in the database
        try {
            String sql = "UPDATE register SET Full_Name = ?, Password = ?, Email = ? WHERE Email = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, newFullName);
            stmt.setString(2, encryptedNewPassword);
            stmt.setString(3, newEmail);
            stmt.setString(4, email);
            stmt.executeUpdate();

            // Update session with new user data
            session.setAttribute("fullName", newFullName);
            session.setAttribute("username", newEmail);

            // Update cookie with new email
            Cookie cookie = new Cookie("username", newEmail);
            cookie.setMaxAge(120);
            response.addCookie(cookie);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Forward to the MyAccount JSP
        request.getRequestDispatcher("/MyAccount.jsp").forward(request, response);
    }

    public void destroy() {
        // Close the database connection
        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
