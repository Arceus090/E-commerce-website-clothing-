package profile;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Products;

@WebServlet("/search")
public class search extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private Connection conn;
    public void init() throws ServletException {
        // Load JDBC driver and connect to the database
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/beast";
            String user = "root";
            String password = "";
            conn = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException | SQLException e) {
        	throw new ServletException("Error initializing database connection", e);
        }
    }
   

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String query = request.getParameter("query");
        String category = request.getParameter("category");
        String sort = request.getParameter("sort");

        List<Products> products = new ArrayList<Products>();
        String sql = "SELECT * FROM product WHERE product_name LIKE ?";

        if (category != null && !category.isEmpty()) {
            sql += " AND product_category = ?";
        }

        if (sort != null && !sort.isEmpty()) {
            if (sort.equals("price")) {
                sql += " ORDER BY product_price DESC";
            } else if (sort.equals("price1")) {
                sql += " ORDER BY product_price ASC";
            }
        }

        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, "%" + query + "%");

            if (category != null && !category.isEmpty()) {
                statement.setString(2, category);
            }

            ResultSet result = statement.executeQuery();

            while (result.next()) {
                Products product = new Products(0, sql, sql, sql, sql, sql);
                product.setProductId(result.getInt("product_id"));
                product.setProductName(result.getString("product_name"));
                product.setProductPrice(result.getString("product_price"));
                product.setProductDescription(result.getString("product_description"));
                product.setProductImage(result.getString("product_image"));
                product.setProductCategory(result.getString("product_category"));
                
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        request.setAttribute("products", products);
        request.getRequestDispatcher("Search.jsp").forward(request, response);
    }

    public void destroy() {
        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
