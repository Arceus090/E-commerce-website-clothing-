package controller.filters.login;

import java.io.IOException;
import java.util.Date;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebFilter(filterName = "AuthenticationFilter", urlPatterns = { "/cart.jsp", "/allproducts.jsp", "/index.jsp" })
public class AuthenticationFilter implements Filter {

    private static final int MAX_SESSION_TIME = 120;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization code goes here, if any
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        HttpSession session = req.getSession(false);

        // Check if the user is logged in by checking the session
        if (session != null && session.getAttribute("username") != null) {
            // User is logged in, check if they are an admin
            boolean isAdmin = false;

            if (session.getAttribute("admin") != null) {
                isAdmin = true;
            }

            String requestURI = req.getRequestURI();

            if (isAdmin && requestURI.contains("index.jsp")) {
                res.sendRedirect(req.getContextPath() + "/allproducts.jsp");
                return;
            }

            if (requestURI.contains("allproducts.jsp") && !isAdmin) {
                res.sendRedirect(req.getContextPath() + "/index.jsp");
                return;
            }

            if (isAdmin && session != null) {
                Date lastAccessTime = new Date(session.getLastAccessedTime());
                Date currentTime = new Date();

                long sessionTime = (currentTime.getTime() - lastAccessTime.getTime()) / 1000;

                if (sessionTime > MAX_SESSION_TIME) {
                    session.invalidate();

                    Cookie[] cookies = req.getCookies();

                    if (cookies != null) {
                        for (Cookie cookie : cookies) {
                            if (cookie.getName().equals("admin")) {
                                cookie.setMaxAge(0);
                                res.addCookie(cookie);
                                break;
                            }
                        }
                    }

                    res.sendRedirect(req.getContextPath() + "/index.jsp");
                    return;
                }

                session.setMaxInactiveInterval(MAX_SESSION_TIME - (int) sessionTime);
            }

            chain.doFilter(request, response);
        } else {
            // User is not logged in, allow access to index.jsp
            chain.doFilter(request, response);
        }
    }

    @Override
    public void destroy() {
        // Cleanup code goes here, if any
    }
}
