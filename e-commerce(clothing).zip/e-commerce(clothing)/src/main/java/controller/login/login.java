package controller.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import resources.MyCipher;

@WebServlet("/login")
public class login extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Connection conn = null;
        RequestDispatcher dispatcher = null;

        String Email = request.getParameter("krish");
        String Password = request.getParameter("raj");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/beast";
            String user = "root";
            String pass = "";
            conn = DriverManager.getConnection(url, user, pass);

            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM register WHERE Email = ?");
            stmt.setString(1, Email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // Decrypt the password
                String decryptedPassword = MyCipher.decrypt(rs.getString("Password"), "monkeydluffyyyyy");

                if (Password.equals(decryptedPassword)) {
                    HttpSession session = request.getSession();
                    session.setAttribute("username", rs.getString("Email"));
                    session.setAttribute("fullName", rs.getString("Full_Name"));
                   

                    Cookie cookie = new Cookie("username", rs.getString("Email"));
                    cookie.setMaxAge(120);
                    response.addCookie(cookie);

                

                    // Check if the user is an admin
                    if (rs.getString("Email").equals("admin@gmail.com")||rs.getString("Password").equals("admin")) {
                    	HttpSession session1 = request.getSession();
                    	session1.setAttribute("admin", rs.getString("Email"));
                    	 response.sendRedirect("allproducts.jsp");
                    	 Cookie cookie1 = new Cookie("admin", rs.getString("Email"));
                         cookie1.setMaxAge(1000);
                         response.addCookie(cookie1);
                       
                       
                    } else {
                        dispatcher = request.getRequestDispatcher("index.jsp");
                        dispatcher.forward(request, response);
                    }
                } else {
                    request.setAttribute("errorMessage", "Incorrect email or password");
                    dispatcher = request.getRequestDispatcher("Login.jsp");
                    dispatcher.forward(request, response);
                    return;
                }
            } else {
                request.setAttribute("errorMessage", "Incorrect email or password");
                dispatcher = request.getRequestDispatcher("Login.jsp");
                dispatcher.forward(request, response);
            }

        } catch (SQLException | ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

        
    
}